// This C# code intentionally triggers compiler warnings
// Uses top-level statements (no Main method required)

using System;
using System.Text;

// Warning: Unused variable
int unusedVariable = 10;

// Warning: Possible null reference assignment
string? maybeNull = null;
string definitelyNotNull = maybeNull!; // null-forgiving operator suppresses warning, but line above triggers it

// Warning: Obsolete method usage
[Obsolete("Use NewMethod instead.")]
static void OldMethod() => Console.WriteLine("Old method called.");

static void NewMethod() => Console.WriteLine("New method called.");

OldMethod(); // triggers CS0612

// Warning: Unused using directive (depends on compiler version)

// Warning: Unused local function
void UnusedFunction()
{
    Console.WriteLine("Never called");
}

// Output to prevent �no meaningful code� optimization
Console.WriteLine("Program executed with warnings.");